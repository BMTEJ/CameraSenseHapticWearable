LRA Driver and LRA schematic
